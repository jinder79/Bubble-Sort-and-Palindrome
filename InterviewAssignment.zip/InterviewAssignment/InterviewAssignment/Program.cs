﻿namespace InterviewAssignment
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;

    public enum SortDirection
    {
        Ascending = 0,
        Descending
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bubble Sort test case results are given below.\n");
            // Sort Ascending with Non-Generic method  approach.
            var input = new[] { 910, 18, 57, 781, 690, 798, 340, 7 };

            Console.WriteLine("Input array before Ascending-Sort.(Non-Generic method)\n");
            Array.ForEach(input, Console.WriteLine);

            Sort.BubbleSort(input);
            Array.ForEach(input, Console.WriteLine);
            Console.WriteLine();

            // Sort Descending with Non-Generic method  approach.
            var input1 = new[] { 7, 340, 798, 690, 781, 57, 18, 910 };

            Console.WriteLine("Input array before Descending-Sort.(Non-Generic method)\n");
            Array.ForEach(input1, Console.WriteLine);

            Sort.BubbleSort(input1, SortDirection.Descending);
            Array.ForEach(input1, Console.WriteLine);
            Console.WriteLine();

            // Sort Ascending with Generic method approach.
            //var list = new List<string> { "Har", "Rinku", "Babu", "Vishav", "Mohinder", "Mandeep", "Surjit", "Arwin", "Sukhwinder" };
            var list = new List<int> { 910, 18, 57, 781, 690, 798, 340, 7 };

            Console.WriteLine("Input array before Ascending-Sort(Generic method).\n");
            list.ForEach(item => Console.WriteLine(item));

            Sort.BubbleSort(list);
            list.ForEach(item => Console.WriteLine(item));
            Console.WriteLine();

            // Pailindrome test case
            Console.WriteLine("Palindrome test case results are given below.\n");
            string inputLine = "redivider  harjinder civic radar rinku Level rotor";

            try
            {
                ExaminePalindrome palindrome = new ExaminePalindrome(inputLine);
                var palindromeList = new List<string>(palindrome.GetPalindromeList());

                Console.WriteLine("Input line-of-words to find palindromes contained in it.\n");
                Array.ForEach(inputLine.Split(new string[] { Environment.NewLine, " " }, StringSplitOptions.RemoveEmptyEntries), Console.WriteLine);

                Console.WriteLine("\nInput contains below mentioned Palindromes.\n");
                palindromeList.ForEach(item => Console.WriteLine(item));

                Console.WriteLine(string.Format("\nInput contains {0} Palindromes.", palindromeList.Count));
            }
            catch (Exception exception)
            {
                //Inject logger here and remove below code line
                Console.WriteLine(exception.Message);
            }

            Console.ReadKey();
        }      
    }

    /// <summary>
    /// Encapsulate bubble sorting.
    /// </summary>
    public static class Sort
    {
        /// <summary>
        /// Sort input integers with provided sort direction. Default is Ascending.
        /// </summary>
        /// <param name="input"></param>
        /// <param name="direction"></param>
        public static void BubbleSort(int[] input, SortDirection direction = SortDirection.Ascending)
        {
            try
            {
                var timer = new Stopwatch();
                timer.Start();

                bool swapped;
                do
                {
                    swapped = false;

                    for (var index = 0; index < input.Length - 1; index++)
                    {
                        var needSwap = direction == SortDirection.Ascending ? input[index] > input[index + 1] : input[index] < input[index + 1];

                        if (needSwap)
                        {
                            var temp = input[index];
                            input[index] = input[index + 1];
                            input[index + 1] = temp;
                            swapped = true;
                        }
                    }

                } while (swapped);

                timer.Stop();
                Console.WriteLine(string.Format("\nExecution-Time taken by non-generic method for {0}-Sort is: {1} ticks. Sorted list is given below.\n", direction, timer.ElapsedTicks));

            }
            catch (Exception exception)
            {
                // Inject Exception Logger here and remove below code line
                Console.WriteLine(exception.Message);
            }
        }

        /// <summary>
        /// Sort input list using default comparer for T type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        /// <param name="comparer"></param>
        public static void BubbleSort<T>(IList<T> list)
        {
            try
            {
                var comparer = Comparer<T>.Default;
                bool stillGoing = true;

                var timer = new Stopwatch();
                timer.Start();

                while (stillGoing)
                {
                    stillGoing = false;
                    for (int index = 0; index < list.Count - 1; index++)
                    {
                        T item = list[index];
                        T nextItem = list[index + 1];
                        if (comparer.Compare(item, nextItem) > 0)
                        {
                            list[index] = nextItem;
                            list[index + 1] = item;
                            stillGoing = true;
                        }
                    }
                }

                timer.Stop();
                Console.WriteLine(string.Format("\nExecution-Time taken by Generic-Sort method is: {0} ticks. Sorted list is given below.\n", timer.ElapsedTicks));
            }
            catch (Exception exception)
            {
                // Inject Exception Logger here and remove below code line
                Console.WriteLine(exception.Message);
            }
        }
    }

    /// <summary>
    /// Encapsulate functionality to check if a particular line of words contains palindrome words in it.
    /// </summary>
    public class ExaminePalindrome
    {
        private string input = null;
        private List<string> wordsList = null;
        private int count=0;

        /// <summary>
        /// Intitialize input words line.
        /// </summary>
        /// <param name="input"></param>
        public ExaminePalindrome(string input)
        {
            this.input = input ?? throw new ArgumentNullException(nameof(input),"Input string cannot be null.");
            this.wordsList = new List<string>(input.Split(new string[] { Environment.NewLine, " "}, StringSplitOptions.RemoveEmptyEntries));
        }

        public int Count { get => count; }

        /// <summary>
        /// Provide list of palindrome words contained in provided input.
        /// </summary>
        /// <returns></returns>
        public IList<string> GetPalindromeList()
        {
            var palindromeList = new List<string>();

            foreach(var word in this.wordsList)
            {
                if (IsPalindrome(word))
                    palindromeList.Add(word);
            }

            this.count = palindromeList.Count;

            return palindromeList;
        }

        /// <summary>
        /// Check if word is palindrome.
        /// </summary>
        /// <param name="word"></param>
        /// <returns></returns>
        private bool IsPalindrome(string word)
        {
            string lowerCaseWord = word.ToLower();

            return lowerCaseWord.SequenceEqual(lowerCaseWord.Reverse());
        }
    }

}
